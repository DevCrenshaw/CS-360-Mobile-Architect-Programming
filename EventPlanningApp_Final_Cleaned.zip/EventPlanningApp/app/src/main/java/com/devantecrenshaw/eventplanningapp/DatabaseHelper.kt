package com.devantecrenshaw.eventplanningapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "EventApp.db"
        private const val DATABASE_VERSION = 2
        // User table
        const val TABLE_USERS = "users"
        const val COLUMN_USER_ID = "user_id"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"
        // Events table
        const val TABLE_EVENTS = "events"
        const val COLUMN_EVENT_ID = "event_id"
        const val COLUMN_EVENT_NAME = "name"
        const val COLUMN_EVENT_DATE = "date"
        const val COLUMN_EVENT_LOCATION = "location"
        const val COLUMN_EVENT_DESCRIPTION = "description"
        const val COLUMN_EVENT_USER_ID = "event_user_id"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create users table
        val createUserTable = """
            CREATE TABLE $TABLE_USERS (
                $COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_USERNAME TEXT UNIQUE NOT NULL,
                $COLUMN_PASSWORD TEXT NOT NULL
            )
        """.trimIndent()

        // Create events table
        val createEventTable = """
            CREATE TABLE $TABLE_EVENTS (
                $COLUMN_EVENT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_EVENT_NAME TEXT NOT NULL,
                $COLUMN_EVENT_DATE TEXT NOT NULL,
                $COLUMN_EVENT_LOCATION TEXT,
                $COLUMN_EVENT_DESCRIPTION TEXT,
                $COLUMN_EVENT_USER_ID INTEGER,
                FOREIGN KEY($COLUMN_EVENT_USER_ID) REFERENCES $TABLE_USERS($COLUMN_USER_ID)
            )
        """.trimIndent()

        db.execSQL(createUserTable)
        db.execSQL(createEventTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {

            db.execSQL("ALTER TABLE $TABLE_EVENTS ADD COLUMN $COLUMN_EVENT_DESCRIPTION TEXT")
        } else {
            // For major version changes, recreate tables
            db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
            db.execSQL("DROP TABLE IF EXISTS $TABLE_EVENTS")
            onCreate(db)
        }
    }

    // User operations
    fun addUser(username: String, password: String): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
        }
        return db.insert(TABLE_USERS, null, values)
    }

    fun checkUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val selection = "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?"
        val selectionArgs = arrayOf(username, password)

        db.query(TABLE_USERS, null, selection, selectionArgs, null, null, null).use { cursor ->
            return cursor.count > 0
        }
    }

    fun getUserId(username: String): Long {
        val db = readableDatabase
        val selection = "$COLUMN_USERNAME = ?"
        val selectionArgs = arrayOf(username)

        db.query(TABLE_USERS, arrayOf(COLUMN_USER_ID), selection, selectionArgs, null, null, null).use { cursor ->
            return if (cursor.moveToFirst()) {
                cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_USER_ID))
            } else {
                -1L
            }
        }
    }

    // In DatabaseHelper.kt
    fun getEventById(eventId: String): Event? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_EVENTS,
            arrayOf(COLUMN_EVENT_ID, COLUMN_EVENT_NAME, COLUMN_EVENT_DATE,
                COLUMN_EVENT_LOCATION, COLUMN_EVENT_DESCRIPTION),
            "$COLUMN_EVENT_ID = ?",
            arrayOf(eventId),
            null, null, null
        )

        return if (cursor.moveToFirst()) {
            Event(
                id = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_ID)),
                name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_NAME)),
                date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_DATE)),
                location = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_LOCATION)),
                description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_DESCRIPTION))
            )
        } else {
            null
        }.also { cursor.close() }
    }

    fun updateEvent(eventId: String, event: Event): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_EVENT_NAME, event.name)
            put(COLUMN_EVENT_DATE, event.date)
            put(COLUMN_EVENT_LOCATION, event.location)
            put(COLUMN_EVENT_DESCRIPTION, event.description)
        }
        return db.update(
            TABLE_EVENTS,
            values,
            "$COLUMN_EVENT_ID = ?",
            arrayOf(eventId)
        )
    }

    fun deleteEvent(eventId: String): Int {
        val db = writableDatabase
        return db.delete(
            TABLE_EVENTS,
            "$COLUMN_EVENT_ID = ?",
            arrayOf(eventId)
        )
    }

    fun addEvent(event: Event, userId: Long): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_EVENT_NAME, event.name)
            put(COLUMN_EVENT_DATE, event.date)
            put(COLUMN_EVENT_LOCATION, event.location)
            put(COLUMN_EVENT_DESCRIPTION, event.description)
            put(COLUMN_EVENT_USER_ID, userId)
        }
        return db.insert(TABLE_EVENTS, null, values)
    }

    fun getAllEvents(userId: Long): List<Event> {
        val events = mutableListOf<Event>()
        val db = readableDatabase
        val selection = "$COLUMN_EVENT_USER_ID = ?"
        val selectionArgs = arrayOf(userId.toString())

        db.query(
            TABLE_EVENTS,
            arrayOf(
                COLUMN_EVENT_ID,
                COLUMN_EVENT_NAME,
                COLUMN_EVENT_DATE,
                COLUMN_EVENT_LOCATION,
                COLUMN_EVENT_DESCRIPTION
            ),
            selection,
            selectionArgs,
            null,
            null,
            "$COLUMN_EVENT_DATE ASC"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                events.add(
                    Event(
                        id = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_ID)),
                        name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_NAME)),
                        date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_DATE)),
                        location = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_LOCATION)),
                        description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_DESCRIPTION))
                    )
                )
            }
        }
        return events
    }
}