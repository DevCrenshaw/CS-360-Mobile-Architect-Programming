package com.devantecrenshaw.eventplanningapp

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

object NotificationHelper {
    private const val CHANNEL_ID = "event_reminders_channel"
    private const val NOTIFICATION_ID = 1001

    fun sendNotification(context: Context, title: String, message: String) {
        val intent = Intent(context, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_event_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    fun sendEventReminder(context: Context, event: Event) {
        val title = "Upcoming Event: ${event.name}"
        val message = "Don't forget about your event at ${event.location} on ${event.date}"

        sendNotification(context, title, message)
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED && SharedPreferencesHelper(context).areNotificationsEnabled()
        ) {
            val phoneNumber = SharedPreferencesHelper(context).getUserPhoneNumber()
            if (phoneNumber.isNotEmpty()) {
                try {
                    val smsManager = SmsManager.getDefault()
                    smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        "$title - $message",
                        null,
                        null
                    )
                } catch (e: Exception) {

                }
            }
        }
    }
}