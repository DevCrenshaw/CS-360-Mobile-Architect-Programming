package com.devantecrenshaw.eventplanningapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.devantecrenshaw.eventplanningapp.databinding.ActivityDashboardBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding
    private lateinit var databaseHelper: DatabaseHelper
    private var userId: Long = -1
    private lateinit var eventAdapter: EventAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        databaseHelper = DatabaseHelper(this)

        userId = intent.getLongExtra("USER_ID", -1L).also {
            if (it == -1L) {
                Toast.makeText(this, "User not identified", Toast.LENGTH_SHORT).show()
                finish()
                return
            }
        }

        setupRecyclerView()
        setupFab()
        setupBottomNavigation()
        loadUserEvents()
    }

    private fun setupRecyclerView() {
        eventAdapter = EventAdapter(
            events = emptyList(),
            onItemClick = { event ->
                AddEventActivity.startForEditEvent(this, userId, event.id)
            },
            onDeleteClick = { event ->
                showDeleteConfirmation(event)
            }
        )

        binding.eventsRecyclerView.apply {
            layoutManager = GridLayoutManager(this@DashboardActivity, 2)
            adapter = eventAdapter
            setHasFixedSize(true)
        }
    }

    private fun showDeleteConfirmation(event: Event) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete Event")
            .setMessage("Are you sure you want to delete '${event.name}'?")
            .setPositiveButton("Delete") { _, _ ->
                deleteEvent(event)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteEvent(event: Event) {
        if (databaseHelper.deleteEvent(event.id) > 0) {
            Snackbar.make(binding.root, "Event deleted successfully", Snackbar.LENGTH_SHORT).show()
            loadUserEvents()
        } else {
            Snackbar.make(binding.root, "Failed to delete event", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun loadUserEvents() {
        val events = databaseHelper.getAllEvents(userId)
        eventAdapter.updateEvents(events)

        if (events.isEmpty()) {
            Snackbar.make(binding.root, "No events found. Create your first event!", Snackbar.LENGTH_LONG)
                .setAction("Create") {
                    AddEventActivity.startForNewEvent(this, userId)
                }
                .show()
        }
    }

    private fun setupFab() {
        binding.addEventFab.setOnClickListener {
            AddEventActivity.startForNewEvent(this, userId)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when {
            requestCode == AddEventActivity.REQUEST_CODE_ADD_EVENT && resultCode == RESULT_OK -> {
                Snackbar.make(binding.root, "Event created successfully", Snackbar.LENGTH_SHORT).show()
                loadUserEvents()
            }
            requestCode == AddEventActivity.REQUEST_CODE_EDIT_EVENT && resultCode == RESULT_OK -> {
                data?.getBooleanExtra(AddEventActivity.RESULT_EVENT_DELETED, false)?.let { deleted ->
                    if (deleted) {
                        Snackbar.make(binding.root, "Event deleted", Snackbar.LENGTH_SHORT).show()
                    } else {
                        Snackbar.make(binding.root, "Event updated", Snackbar.LENGTH_SHORT).show()
                    }
                }
                loadUserEvents()
            }
        }
    }

    private fun setupBottomNavigation() {
        binding.bottomNav.selectedItemId = R.id.nav_home

        binding.bottomNav.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    loadUserEvents()
                    true
                }
                R.id.nav_notifications -> {
                    Intent(this, NotificationActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                        putExtra("USER_ID", userId)
                        startActivity(this)
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    }
                    true
                }
                R.id.nav_profile -> {
                    MaterialAlertDialogBuilder(this)
                        .setTitle("Profile Options")
                        .setItems(arrayOf("View Profile", "Settings", "Logout")) { _, which ->
                            when (which) {
                                0 -> showProfile()
                                1 -> showSettings()
                                2 -> logout()
                            }
                        }
                        .show()
                    true
                }
                else -> false
            }
        }
    }

    private fun showProfile() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Profile")
            .setMessage("Profile view coming soon!")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showSettings() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Settings")
            .setMessage("Settings will be available in the next update")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun logout() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Yes") { _, _ ->
                finish()
            }
            .setNegativeButton("No", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        loadUserEvents()
    }
}