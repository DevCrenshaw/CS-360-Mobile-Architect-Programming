package com.devantecrenshaw.eventplanningapp

data class Event(
    val id: String = "",
    val name: String = "",
    val date: String = "",
    val location: String = "",
    val description: String = ""
)