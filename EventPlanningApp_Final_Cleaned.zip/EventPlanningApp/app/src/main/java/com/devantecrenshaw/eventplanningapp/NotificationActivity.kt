package com.devantecrenshaw.eventplanningapp

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.devantecrenshaw.eventplanningapp.databinding.ActivityNotificationBinding

class NotificationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNotificationBinding
    private val SMS_PERMISSION_CODE = 101
    private val NOTIFICATION_CHANNEL_ID = "event_reminders_channel"
    private lateinit var sharedPrefs: SharedPreferencesHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationBinding.inflate(layoutInflater)
        setContentView(binding.root)
        sharedPrefs = SharedPreferencesHelper(this)

        createNotificationChannel()
        setupUI()
        checkPermissionStatus()
    }

    private fun setupUI() {
        binding.notificationSwitch.isChecked = sharedPrefs.areNotificationsEnabled()

        binding.notificationSwitch.setOnCheckedChangeListener { _, isChecked ->
            sharedPrefs.setNotificationsEnabled(isChecked)
            if (isChecked && !hasSmsPermission()) {
                requestSmsPermission()
                binding.notificationSwitch.isChecked = false
            } else {
                val message = if (isChecked) "Notifications enabled" else "Notifications disabled"
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }
        }

        binding.requestPermissionButton.setOnClickListener {
            requestSmsPermission()
        }

        binding.testNotificationButton.setOnClickListener {
            sendTestNotification()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Event Reminders"
            val descriptionText = "Notifications for upcoming events"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(NOTIFICATION_CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun checkPermissionStatus() {
        if (hasSmsPermission()) {
            binding.notificationStatus.text = getString(R.string.notification_status_granted)
            binding.requestPermissionButton.visibility = View.GONE
        } else {
            binding.notificationStatus.text = getString(R.string.notification_status_denied)
            binding.requestPermissionButton.visibility = View.VISIBLE
        }
    }

    private fun hasSmsPermission() = ContextCompat.checkSelfPermission(
        this,
        Manifest.permission.SEND_SMS
    ) == PackageManager.PERMISSION_GRANTED

    private fun requestSmsPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(
                this,
                Manifest.permission.SEND_SMS
            )) {
            AlertDialog.Builder(this)
                .setTitle("Permission Needed")
                .setMessage("SMS permission is required to send event reminders")
                .setPositiveButton("OK") { _, _ ->
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.SEND_SMS),
                        SMS_PERMISSION_CODE
                    )
                }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_CODE
            )
        }
    }

    private fun sendTestNotification() {
        if (sharedPrefs.areNotificationsEnabled()) {
            if (hasSmsPermission()) {
                // Send test SMS
                try {
                    val smsManager = SmsManager.getDefault()
                    val phoneNumber = sharedPrefs.getUserPhoneNumber()
                    if (phoneNumber.isNotEmpty()) {
                        smsManager.sendTextMessage(
                            phoneNumber,
                            null,
                            "Test notification from Event Planner App",
                            null,
                            null
                        )
                        Toast.makeText(this, "Test SMS sent", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Please set your phone number in settings", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Failed to send SMS: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            // Send in-app notification
            NotificationHelper.sendNotification(
                this,
                "Test Notification",
                "This is a test notification from your Event Planner App"
            )
        } else {
            Toast.makeText(this, "Notifications are disabled", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show()
                binding.notificationSwitch.isChecked = true
                sharedPrefs.setNotificationsEnabled(true)
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
                binding.notificationSwitch.isChecked = false
                sharedPrefs.setNotificationsEnabled(false)
            }
            checkPermissionStatus()
        }
    }
}