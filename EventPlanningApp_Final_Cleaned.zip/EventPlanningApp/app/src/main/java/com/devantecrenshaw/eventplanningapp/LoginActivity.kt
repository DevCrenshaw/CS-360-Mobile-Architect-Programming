package com.devantecrenshaw.eventplanningapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.devantecrenshaw.eventplanningapp.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        databaseHelper = DatabaseHelper(this)

        binding.loginButton.setOnClickListener {
            val username = binding.usernameInput.text.toString()
            val password = binding.passwordInput.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                if (databaseHelper.checkUser(username, password)) {
                    val userId = databaseHelper.getUserId(username)
                    if (userId != -1L) {
                        startActivity(Intent(this, DashboardActivity::class.java).apply {
                            putExtra("USER_ID", userId)
                            putExtra("USERNAME", username)
                        })
                        finish()
                    } else {
                        Toast.makeText(this, "Error: User ID not found", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
            }
        }

        binding.createAccountButton.setOnClickListener {
            val username = binding.usernameInput.text.toString()
            val password = binding.passwordInput.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                val userId = databaseHelper.addUser(username, password)
                if (userId != -1L) {
                    Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show()
                    // Auto-login after account creation
                    startActivity(Intent(this, DashboardActivity::class.java).apply {
                        putExtra("USER_ID", userId)
                        putExtra("USERNAME", username)
                    })
                    finish()
                } else {
                    Toast.makeText(this, "Account creation failed. Username may exist.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
            }
        }
    }
}