package com.devantecrenshaw.eventplanningapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.devantecrenshaw.eventplanningapp.databinding.EventCardBinding
import java.text.SimpleDateFormat
import java.util.*

class EventAdapter(
    private var events: List<Event>,
    private val onItemClick: (Event) -> Unit,
    private val onDeleteClick: (Event) -> Unit
) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    fun updateEvents(newEvents: List<Event>) {
        events = newEvents.sortedBy { parseDate(it.date) }
        notifyDataSetChanged()
    }

    inner class EventViewHolder(private val binding: EventCardBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(event: Event) {
            binding.apply {
                eventName.text = event.name
                eventDate.text = formatDateTime(event.date)
                eventLocation.text = event.location.ifEmpty { "No location specified" }
                eventDescription.text = event.description.ifEmpty { "No description available" }

                // Set click listeners
                root.setOnClickListener { onItemClick(event) }
                deleteButton.setOnClickListener { onDeleteClick(event) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        return EventViewHolder(
            EventCardBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        holder.bind(events[position])
    }

    override fun getItemCount() = events.size

    private fun formatDateTime(dateTimeString: String): String {
        return try {
            val inputFormat = SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.getDefault())
            val date = inputFormat.parse(dateTimeString) ?: return dateTimeString

            val dateFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
            val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())

            "${dateFormat.format(date)} at ${timeFormat.format(date)}"
        } catch (e: Exception) {
            dateTimeString
        }
    }

    private fun parseDate(dateString: String): Date? {
        return try {
            SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.getDefault()).parse(dateString)
        } catch (e: Exception) {
            null
        }
    }
}