package com.devantecrenshaw.eventplanningapp

import android.content.Context
import android.content.SharedPreferences

class SharedPreferencesHelper(context: Context) {
    private val sharedPref: SharedPreferences = context.getSharedPreferences("EventAppPrefs", Context.MODE_PRIVATE)

    fun areNotificationsEnabled(): Boolean {
        return sharedPref.getBoolean("notifications_enabled", false)
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        sharedPref.edit().putBoolean("notifications_enabled", enabled).apply()
    }

    fun getUserPhoneNumber(): String {
        return sharedPref.getString("user_phone_number", "") ?: ""
    }

    fun setUserPhoneNumber(phoneNumber: String) {
        sharedPref.edit().putString("user_phone_number", phoneNumber).apply()
    }
}