package com.devantecrenshaw.eventplanningapp

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.devantecrenshaw.eventplanningapp.databinding.ActivityAddEventBinding
import java.text.SimpleDateFormat
import java.util.*

class AddEventActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEventBinding
    private lateinit var databaseHelper: DatabaseHelper
    private var userId: Long = -1
    private var eventId: String? = null
    private var isEditMode = false

    companion object {
        const val REQUEST_CODE_ADD_EVENT = 1001
        const val REQUEST_CODE_EDIT_EVENT = 1002
        const val EXTRA_EVENT_ID = "event_id"
        const val EXTRA_USER_ID = "user_id"
        const val RESULT_EVENT_DELETED = "EVENT_DELETED"

        fun startForNewEvent(context: Context, userId: Long) {
            val intent = Intent(context, AddEventActivity::class.java).apply {
                putExtra(EXTRA_USER_ID, userId)
            }
            (context as AppCompatActivity).startActivityForResult(intent, REQUEST_CODE_ADD_EVENT)
        }

        fun startForEditEvent(context: Context, userId: Long, eventId: String) {
            val intent = Intent(context, AddEventActivity::class.java).apply {
                putExtra(EXTRA_USER_ID, userId)
                putExtra(EXTRA_EVENT_ID, eventId)
            }
            (context as AppCompatActivity).startActivityForResult(intent, REQUEST_CODE_EDIT_EVENT)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEventBinding.inflate(layoutInflater)
        setContentView(binding.root)
        databaseHelper = DatabaseHelper(this)

        // Get user ID and event ID from intent
        userId = intent.getLongExtra(EXTRA_USER_ID, -1L).also {
            if (it == -1L) {
                Toast.makeText(this, "User not identified", Toast.LENGTH_SHORT).show()
                finish()
                return
            }
        }

        eventId = intent.getStringExtra(EXTRA_EVENT_ID)
        isEditMode = eventId != null

        if (isEditMode) {
            // Load existing event data
            loadEventData()
            binding.saveEventButton.text = getString(R.string.update_event_button_text)
        }

        setupDatePicker()
        setupTimePicker()
        setupButtons()
    }

    private fun loadEventData() {
        eventId?.let { id ->
            val event = databaseHelper.getEventById(id)
            event?.let {
                binding.eventNameInput.setText(it.name)
                binding.eventDateInput.setText(it.date)
                binding.eventLocationInput.setText(it.location)
                binding.eventDescriptionInput.setText(it.description)

                // Parse date and time if they're stored separately
                // (You might need to adjust this based on your actual date/time format)
                val dateTimeParts = it.date.split(" ")
                if (dateTimeParts.size >= 2) {
                    binding.eventDateInput.setText(dateTimeParts[0])
                    binding.eventTimeInput.setText(dateTimeParts[1])
                }
            } ?: run {
                Toast.makeText(this, "Event not found", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun setupDatePicker() {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            calendar.set(year, month, dayOfMonth)
            val dateFormat = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
            binding.eventDateInput.setText(dateFormat.format(calendar.time))
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))

        binding.eventDateInput.setOnClickListener {
            datePicker.show()
        }
    }

    private fun setupTimePicker() {
        val calendar = Calendar.getInstance()
        val timePicker = TimePickerDialog(this, { _, hourOfDay, minute ->
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
            calendar.set(Calendar.MINUTE, minute)
            val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
            binding.eventTimeInput.setText(timeFormat.format(calendar.time))
        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false)

        binding.eventTimeInput.setOnClickListener {
            timePicker.show()
        }
    }

    private fun setupButtons() {
        binding.saveEventButton.setOnClickListener {
            if (validateInputs()) {
                if (isEditMode) {
                    updateEvent()
                } else {
                    saveEvent()
                }
            }
        }

        binding.cancelButton.setOnClickListener {
            finish()
        }
    }

    private fun validateInputs(): Boolean {
        if (binding.eventNameInput.text.isNullOrEmpty()) {
            binding.eventNameLayout.error = "Event name is required"
            return false
        }
        binding.eventNameLayout.error = null

        if (binding.eventDateInput.text.isNullOrEmpty()) {
            binding.eventDateLayout.error = "Date is required"
            return false
        }
        binding.eventDateLayout.error = null

        if (binding.eventTimeInput.text.isNullOrEmpty()) {
            binding.eventTimeLayout.error = "Time is required"
            return false
        }
        binding.eventTimeLayout.error = null

        return true
    }

    private fun saveEvent() {
        val event = Event(
            id = "",
            name = binding.eventNameInput.text.toString(),
            date = "${binding.eventDateInput.text} ${binding.eventTimeInput.text}",
            location = binding.eventLocationInput.text.toString(),
            description = binding.eventDescriptionInput.text.toString()
        )

        val insertedId = databaseHelper.addEvent(event, userId)
        if (insertedId != -1L) {
            Toast.makeText(this, "Event saved successfully", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
            finish()
        } else {
            Toast.makeText(this, "Failed to save event", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateEvent() {
        eventId?.let { id ->
            val event = Event(
                id = id,
                name = binding.eventNameInput.text.toString(),
                date = "${binding.eventDateInput.text} ${binding.eventTimeInput.text}",
                location = binding.eventLocationInput.text.toString(),
                description = binding.eventDescriptionInput.text.toString()
            )

            val rowsAffected = databaseHelper.updateEvent(id, event)
            if (rowsAffected > 0) {
                Toast.makeText(this, "Event updated successfully", Toast.LENGTH_SHORT).show()
                setResult(RESULT_OK)
                finish()
            } else {
                Toast.makeText(this, "Failed to update event", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun deleteEvent() {
        eventId?.let { id ->
            val rowsDeleted = databaseHelper.deleteEvent(id)
            if (rowsDeleted > 0) {
                Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show()
                val resultIntent = Intent().apply {
                    putExtra(RESULT_EVENT_DELETED, true)
                }
                setResult(RESULT_OK, resultIntent)
                finish()
            } else {
                Toast.makeText(this, "Failed to delete event", Toast.LENGTH_SHORT).show()
            }
        }
    }
}